//
//  AppDelegate.h
//  CollectionViewOP
//
//  Created by lxw on 2018/5/9.
//  Copyright © 2018年 lxw. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

